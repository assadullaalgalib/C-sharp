﻿namespace BikeServiceManagement
{
    partial class create_admin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label4 = new Label();
            pictureBox1 = new PictureBox();
            price_bx = new TextBox();
            pictureBox8 = new PictureBox();
            sn_box = new TextBox();
            pictureBox5 = new PictureBox();
            label6 = new Label();
            button2 = new Button();
            label1 = new Label();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(25, 35, 57);
            label4.Font = new Font("Century Gothic", 12.75F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(187, 150, 132);
            label4.Location = new Point(14, 16);
            label4.Name = "label4";
            label4.Size = new Size(70, 19);
            label4.TabIndex = 28;
            label4.Text = "CREATE";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(25, 35, 57);
            pictureBox1.Dock = DockStyle.Top;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(691, 50);
            pictureBox1.TabIndex = 27;
            pictureBox1.TabStop = false;
            // 
            // price_bx
            // 
            price_bx.BackColor = Color.FromArgb(33, 46, 74);
            price_bx.BorderStyle = BorderStyle.None;
            price_bx.Cursor = Cursors.Hand;
            price_bx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            price_bx.ForeColor = Color.White;
            price_bx.Location = new Point(365, 215);
            price_bx.Name = "price_bx";
            price_bx.RightToLeft = RightToLeft.No;
            price_bx.Size = new Size(296, 24);
            price_bx.TabIndex = 58;
            price_bx.TextChanged += price_bx_TextChanged;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox8.BackgroundImageLayout = ImageLayout.None;
            pictureBox8.Location = new Point(354, 190);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(307, 61);
            pictureBox8.TabIndex = 59;
            pictureBox8.TabStop = false;
            // 
            // sn_box
            // 
            sn_box.BackColor = Color.FromArgb(33, 46, 74);
            sn_box.BorderStyle = BorderStyle.None;
            sn_box.Cursor = Cursors.Hand;
            sn_box.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            sn_box.ForeColor = Color.White;
            sn_box.Location = new Point(41, 215);
            sn_box.Name = "sn_box";
            sn_box.RightToLeft = RightToLeft.No;
            sn_box.Size = new Size(296, 24);
            sn_box.TabIndex = 55;
            sn_box.TextChanged += sn_box_TextChanged;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox5.BackgroundImageLayout = ImageLayout.None;
            pictureBox5.Location = new Point(30, 190);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(307, 61);
            pictureBox5.TabIndex = 56;
            pictureBox5.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.FlatStyle = FlatStyle.Flat;
            label6.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.LightGray;
            label6.Location = new Point(14, 87);
            label6.Name = "label6";
            label6.Size = new Size(103, 19);
            label6.TabIndex = 54;
            label6.Text = "Add Service";
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(248, 177, 121);
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.FromArgb(22, 30, 49);
            button2.Location = new Point(300, 351);
            button2.Name = "button2";
            button2.Size = new Size(97, 28);
            button2.TabIndex = 61;
            button2.Text = "Confirm";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.DarkGray;
            label1.Location = new Point(30, 156);
            label1.Name = "label1";
            label1.Size = new Size(118, 19);
            label1.TabIndex = 62;
            label1.Text = "Service Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.DarkGray;
            label2.Location = new Point(354, 156);
            label2.Name = "label2";
            label2.Size = new Size(47, 19);
            label2.TabIndex = 63;
            label2.Text = "Price";
            // 
            // create_admin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(22, 30, 49);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(price_bx);
            Controls.Add(pictureBox8);
            Controls.Add(sn_box);
            Controls.Add(pictureBox5);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(pictureBox1);
            Name = "create_admin";
            Size = new Size(691, 540);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label4;
        private PictureBox pictureBox1;
        private TextBox price_bx;
        private PictureBox pictureBox8;
        private TextBox sn_box;
        private PictureBox pictureBox5;
        private Label label6;
        private Button button2;
        private Label label1;
        private Label label2;
    }
}
