﻿namespace BikeServiceManagement
{
    partial class home_cus
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            payment_panel = new Panel();
            TC_Label = new Label();
            HS_Label = new Label();
            Date_Label = new Label();
            SN_Label = new Label();
            SP_label = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label9 = new Label();
            label5 = new Label();
            button1 = new Button();
            thnku_panel = new Panel();
            label7 = new Label();
            label10 = new Label();
            label8 = new Label();
            label6 = new Label();
            button2 = new Button();
            service_panel = new Panel();
            comboBox1 = new ComboBox();
            label2 = new Label();
            button4 = new Button();
            checkBox1 = new CheckBox();
            dateTimePicker1 = new DateTimePicker();
            comboBox2 = new ComboBox();
            label3 = new Label();
            label1 = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            payment_panel.SuspendLayout();
            thnku_panel.SuspendLayout();
            service_panel.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(25, 35, 57);
            pictureBox1.Dock = DockStyle.Top;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(691, 50);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // payment_panel
            // 
            payment_panel.Controls.Add(TC_Label);
            payment_panel.Controls.Add(HS_Label);
            payment_panel.Controls.Add(Date_Label);
            payment_panel.Controls.Add(SN_Label);
            payment_panel.Controls.Add(SP_label);
            payment_panel.Controls.Add(label14);
            payment_panel.Controls.Add(label13);
            payment_panel.Controls.Add(label12);
            payment_panel.Controls.Add(label11);
            payment_panel.Controls.Add(label9);
            payment_panel.Controls.Add(label5);
            payment_panel.Controls.Add(button1);
            payment_panel.Location = new Point(82, 52);
            payment_panel.Name = "payment_panel";
            payment_panel.Size = new Size(558, 431);
            payment_panel.TabIndex = 25;
            // 
            // TC_Label
            // 
            TC_Label.AutoSize = true;
            TC_Label.FlatStyle = FlatStyle.Flat;
            TC_Label.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            TC_Label.ForeColor = Color.DarkGray;
            TC_Label.Location = new Point(179, 257);
            TC_Label.Name = "TC_Label";
            TC_Label.Size = new Size(78, 18);
            TC_Label.TabIndex = 28;
            TC_Label.Text = "Total Cost";
            // 
            // HS_Label
            // 
            HS_Label.AutoSize = true;
            HS_Label.FlatStyle = FlatStyle.Flat;
            HS_Label.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            HS_Label.ForeColor = Color.DarkGray;
            HS_Label.Location = new Point(179, 214);
            HS_Label.Name = "HS_Label";
            HS_Label.Size = new Size(111, 18);
            HS_Label.TabIndex = 28;
            HS_Label.Text = "Home Service";
            // 
            // Date_Label
            // 
            Date_Label.AutoSize = true;
            Date_Label.FlatStyle = FlatStyle.Flat;
            Date_Label.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            Date_Label.ForeColor = Color.DarkGray;
            Date_Label.Location = new Point(179, 172);
            Date_Label.Name = "Date_Label";
            Date_Label.Size = new Size(43, 18);
            Date_Label.TabIndex = 28;
            Date_Label.Text = "Date";
            // 
            // SN_Label
            // 
            SN_Label.AutoSize = true;
            SN_Label.FlatStyle = FlatStyle.Flat;
            SN_Label.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            SN_Label.ForeColor = Color.DarkGray;
            SN_Label.Location = new Point(179, 131);
            SN_Label.Name = "SN_Label";
            SN_Label.Size = new Size(112, 18);
            SN_Label.TabIndex = 28;
            SN_Label.Text = "Service Name";
            // 
            // SP_label
            // 
            SP_label.AutoSize = true;
            SP_label.FlatStyle = FlatStyle.Flat;
            SP_label.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            SP_label.ForeColor = Color.DarkGray;
            SP_label.Location = new Point(179, 90);
            SP_label.Name = "SP_label";
            SP_label.Size = new Size(127, 18);
            SP_label.TabIndex = 28;
            SP_label.Text = "Service Provider";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.FlatStyle = FlatStyle.Flat;
            label14.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label14.ForeColor = Color.DarkGray;
            label14.Location = new Point(41, 257);
            label14.Name = "label14";
            label14.Size = new Size(78, 18);
            label14.TabIndex = 27;
            label14.Text = "Total Cost";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.FlatStyle = FlatStyle.Flat;
            label13.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = Color.DarkGray;
            label13.Location = new Point(41, 214);
            label13.Name = "label13";
            label13.Size = new Size(111, 18);
            label13.TabIndex = 27;
            label13.Text = "Home Service";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.FlatStyle = FlatStyle.Flat;
            label12.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.DarkGray;
            label12.Location = new Point(41, 172);
            label12.Name = "label12";
            label12.Size = new Size(43, 18);
            label12.TabIndex = 26;
            label12.Text = "Date";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.FromArgb(22, 30, 49);
            label11.FlatStyle = FlatStyle.Flat;
            label11.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.DarkGray;
            label11.Location = new Point(41, 131);
            label11.Name = "label11";
            label11.Size = new Size(112, 18);
            label11.TabIndex = 26;
            label11.Text = "Service Name";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.FlatStyle = FlatStyle.Flat;
            label9.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.DarkGray;
            label9.Location = new Point(41, 90);
            label9.Name = "label9";
            label9.Size = new Size(127, 18);
            label9.TabIndex = 18;
            label9.Text = "Service Provider";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.LightGray;
            label5.Location = new Point(31, 32);
            label5.Name = "label5";
            label5.Size = new Size(143, 19);
            label5.TabIndex = 16;
            label5.Text = "Confirm Payment";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(248, 177, 121);
            button1.BackgroundImageLayout = ImageLayout.None;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.FromArgb(22, 30, 49);
            button1.Location = new Point(235, 339);
            button1.Name = "button1";
            button1.Size = new Size(97, 28);
            button1.TabIndex = 15;
            button1.Text = "Confirm";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // thnku_panel
            // 
            thnku_panel.Controls.Add(label7);
            thnku_panel.Controls.Add(label10);
            thnku_panel.Controls.Add(label8);
            thnku_panel.Controls.Add(label6);
            thnku_panel.Controls.Add(button2);
            thnku_panel.Location = new Point(78, 53);
            thnku_panel.Name = "thnku_panel";
            thnku_panel.Size = new Size(558, 431);
            thnku_panel.TabIndex = 26;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.FlatStyle = FlatStyle.Flat;
            label7.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.LightGray;
            label7.Location = new Point(24, 44);
            label7.Name = "label7";
            label7.Size = new Size(306, 25);
            label7.TabIndex = 16;
            label7.Text = "Thank You For Your Purchase";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.FlatStyle = FlatStyle.Flat;
            label10.Font = new Font("Century Gothic", 27.75F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.FromArgb(248, 177, 121);
            label10.Location = new Point(321, 29);
            label10.Name = "label10";
            label10.Size = new Size(29, 44);
            label10.TabIndex = 17;
            label10.Text = ".";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.FlatStyle = FlatStyle.Flat;
            label8.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.Silver;
            label8.Location = new Point(28, 136);
            label8.Name = "label8";
            label8.Size = new Size(237, 16);
            label8.TabIndex = 16;
            label8.Text = "We will contact you soon via email.";
            label8.Click += label6_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.FlatStyle = FlatStyle.Flat;
            label6.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.LightGray;
            label6.Location = new Point(28, 104);
            label6.Name = "label6";
            label6.Size = new Size(164, 19);
            label6.TabIndex = 16;
            label6.Text = "Payment Successful.";
            label6.Click += label6_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(248, 177, 121);
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.FromArgb(22, 30, 49);
            button2.Location = new Point(219, 339);
            button2.Name = "button2";
            button2.Size = new Size(97, 28);
            button2.TabIndex = 15;
            button2.Text = "Return";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // service_panel
            // 
            service_panel.Controls.Add(comboBox1);
            service_panel.Controls.Add(label2);
            service_panel.Controls.Add(button4);
            service_panel.Controls.Add(checkBox1);
            service_panel.Controls.Add(dateTimePicker1);
            service_panel.Controls.Add(comboBox2);
            service_panel.Controls.Add(label3);
            service_panel.Controls.Add(label1);
            service_panel.Location = new Point(85, 55);
            service_panel.Name = "service_panel";
            service_panel.Size = new Size(558, 431);
            service_panel.TabIndex = 3;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.FromArgb(33, 46, 74);
            comboBox1.Cursor = Cursors.Hand;
            comboBox1.FlatStyle = FlatStyle.Flat;
            comboBox1.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            comboBox1.ForeColor = Color.Gainsboro;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(37, 156);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(405, 26);
            comboBox1.TabIndex = 25;
            comboBox1.Text = "Services";
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged_1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(22, 30, 49);
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.DarkGray;
            label2.Location = new Point(27, 119);
            label2.Name = "label2";
            label2.Size = new Size(65, 19);
            label2.TabIndex = 24;
            label2.Text = "Service";
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(248, 177, 121);
            button4.BackgroundImageLayout = ImageLayout.None;
            button4.Cursor = Cursors.Hand;
            button4.FlatStyle = FlatStyle.Popup;
            button4.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button4.ForeColor = Color.FromArgb(22, 30, 49);
            button4.Location = new Point(219, 339);
            button4.Name = "button4";
            button4.Size = new Size(97, 28);
            button4.TabIndex = 15;
            button4.Text = "Next";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackgroundImageLayout = ImageLayout.None;
            checkBox1.Cursor = Cursors.Hand;
            checkBox1.FlatStyle = FlatStyle.Flat;
            checkBox1.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox1.ForeColor = Color.DarkGray;
            checkBox1.Location = new Point(31, 285);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(198, 23);
            checkBox1.TabIndex = 23;
            checkBox1.Text = "Home Service (+ $100)";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.CalendarFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            dateTimePicker1.CalendarForeColor = Color.DarkGray;
            dateTimePicker1.CalendarMonthBackground = Color.FromArgb(33, 46, 74);
            dateTimePicker1.CalendarTitleBackColor = Color.FromArgb(33, 46, 74);
            dateTimePicker1.CalendarTitleForeColor = Color.DarkGray;
            dateTimePicker1.CalendarTrailingForeColor = Color.Gray;
            dateTimePicker1.Cursor = Cursors.Hand;
            dateTimePicker1.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            dateTimePicker1.Location = new Point(37, 238);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(258, 26);
            dateTimePicker1.TabIndex = 22;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // comboBox2
            // 
            comboBox2.BackColor = Color.FromArgb(33, 46, 74);
            comboBox2.Cursor = Cursors.Hand;
            comboBox2.FlatStyle = FlatStyle.Flat;
            comboBox2.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            comboBox2.ForeColor = Color.Gainsboro;
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(37, 74);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(405, 26);
            comboBox2.TabIndex = 21;
            comboBox2.Text = "Service Providers";
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.DarkGray;
            label3.Location = new Point(27, 201);
            label3.Name = "label3";
            label3.Size = new Size(45, 19);
            label3.TabIndex = 2;
            label3.Text = "Date";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.DarkGray;
            label1.Location = new Point(27, 37);
            label1.Name = "label1";
            label1.Size = new Size(132, 19);
            label1.TabIndex = 2;
            label1.Text = "Service Provider";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(25, 35, 57);
            label4.Font = new Font("Century Gothic", 12.75F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(187, 150, 132);
            label4.Location = new Point(14, 16);
            label4.Name = "label4";
            label4.Size = new Size(59, 19);
            label4.TabIndex = 24;
            label4.Text = "HOME";
            // 
            // home_cus
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(22, 30, 49);
            Controls.Add(label4);
            Controls.Add(pictureBox1);
            Controls.Add(service_panel);
            Controls.Add(thnku_panel);
            Controls.Add(payment_panel);
            Name = "home_cus";
            Size = new Size(691, 540);
            Load += home_cus_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            payment_panel.ResumeLayout(false);
            payment_panel.PerformLayout();
            thnku_panel.ResumeLayout(false);
            thnku_panel.PerformLayout();
            service_panel.ResumeLayout(false);
            service_panel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label label4;
        private Panel payment_panel;
        private Label label5;
        private Button button1;
        private Button button3;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label9;
        private Label label14;
        private Label label18;
        private Label label17;
        private Label Date_Label;
        private Label SN_Label;
        private Label SP_label;
        private Label TC_Label;
        private Label HS_Label;
        private Panel thnku_panel;
        private Label label7;
        private Label label10;
        private Label label8;
        private Label label6;
        private Button button2;
        private Panel service_panel;
        private ComboBox comboBox1;
        private Label label2;
        private Button button4;
        private CheckBox checkBox1;
        private DateTimePicker dateTimePicker1;
        private ComboBox comboBox2;
        private Label label3;
        private Label label1;
    }
}
