﻿namespace BikeServiceManagement
{
    partial class UserLoginReg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserLoginReg));
            LoginPan = new Panel();
            label18 = new Label();
            label17 = new Label();
            label16 = new Label();
            button3 = new Button();
            checkBox1 = new CheckBox();
            homeYellowbx = new PictureBox();
            label7 = new Label();
            passtxtbx = new TextBox();
            pictureBox2 = new PictureBox();
            label6 = new Label();
            usernametxtbx = new TextBox();
            pictureBox1 = new PictureBox();
            label4 = new Label();
            label5 = new Label();
            regpan = new Panel();
            label21 = new Label();
            label20 = new Label();
            label19 = new Label();
            label14 = new Label();
            textBox6 = new TextBox();
            pictureBox9 = new PictureBox();
            label13 = new Label();
            emtxtbx = new TextBox();
            pictureBox8 = new PictureBox();
            label12 = new Label();
            lntxtbx = new TextBox();
            pictureBox7 = new PictureBox();
            label11 = new Label();
            fntxtbx = new TextBox();
            pictureBox6 = new PictureBox();
            textBox5 = new TextBox();
            button4 = new Button();
            checkBox2 = new CheckBox();
            pictureBox3 = new PictureBox();
            label3 = new Label();
            textBox3 = new TextBox();
            pictureBox4 = new PictureBox();
            label8 = new Label();
            textBox4 = new TextBox();
            pictureBox5 = new PictureBox();
            label9 = new Label();
            label10 = new Label();
            button1 = new Button();
            button2 = new Button();
            label2 = new Label();
            label1 = new Label();
            pictureBox10 = new PictureBox();
            label15 = new Label();
            button5 = new Button();
            LoginPan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)homeYellowbx).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            regpan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            SuspendLayout();
            // 
            // LoginPan
            // 
            LoginPan.Controls.Add(label18);
            LoginPan.Controls.Add(label17);
            LoginPan.Controls.Add(label16);
            LoginPan.Controls.Add(button3);
            LoginPan.Controls.Add(checkBox1);
            LoginPan.Controls.Add(homeYellowbx);
            LoginPan.Controls.Add(label7);
            LoginPan.Controls.Add(passtxtbx);
            LoginPan.Controls.Add(pictureBox2);
            LoginPan.Controls.Add(label6);
            LoginPan.Controls.Add(usernametxtbx);
            LoginPan.Controls.Add(pictureBox1);
            LoginPan.Controls.Add(label4);
            LoginPan.Controls.Add(label5);
            LoginPan.Location = new Point(32, 52);
            LoginPan.Name = "LoginPan";
            LoginPan.Size = new Size(750, 433);
            LoginPan.TabIndex = 3;
            LoginPan.Paint += LoginPan_Paint_1;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Cursor = Cursors.Hand;
            label18.FlatStyle = FlatStyle.Flat;
            label18.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label18.ForeColor = Color.FromArgb(248, 177, 121);
            label18.Location = new Point(186, 370);
            label18.Name = "label18";
            label18.RightToLeft = RightToLeft.No;
            label18.Size = new Size(58, 17);
            label18.TabIndex = 20;
            label18.Text = "Register";
            label18.Click += label18_Click;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.FlatStyle = FlatStyle.Flat;
            label17.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label17.ForeColor = Color.DarkGray;
            label17.Location = new Point(26, 370);
            label17.Name = "label17";
            label17.RightToLeft = RightToLeft.No;
            label17.Size = new Size(164, 17);
            label17.TabIndex = 19;
            label17.Text = "Don't have an account.";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.FlatStyle = FlatStyle.Flat;
            label16.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label16.ForeColor = Color.DarkGray;
            label16.Location = new Point(26, 100);
            label16.Name = "label16";
            label16.RightToLeft = RightToLeft.No;
            label16.Size = new Size(205, 17);
            label16.TabIndex = 18;
            label16.Text = "Please sign in to your account.";
            label16.Click += label16_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(248, 177, 121);
            button3.BackgroundImageLayout = ImageLayout.None;
            button3.Cursor = Cursors.Hand;
            button3.FlatStyle = FlatStyle.Popup;
            button3.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button3.ForeColor = Color.FromArgb(22, 30, 49);
            button3.Location = new Point(26, 330);
            button3.Name = "button3";
            button3.Size = new Size(97, 28);
            button3.TabIndex = 14;
            button3.Text = "Login";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click_1;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = Color.FromArgb(22, 30, 49);
            checkBox1.BackgroundImageLayout = ImageLayout.None;
            checkBox1.Cursor = Cursors.Hand;
            checkBox1.FlatStyle = FlatStyle.Flat;
            checkBox1.Font = new Font("Lato Semibold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox1.ForeColor = Color.LightSlateGray;
            checkBox1.Location = new Point(26, 273);
            checkBox1.Name = "checkBox1";
            checkBox1.RightToLeft = RightToLeft.No;
            checkBox1.Size = new Size(113, 20);
            checkBox1.TabIndex = 13;
            checkBox1.Text = "Show Password";
            checkBox1.UseVisualStyleBackColor = false;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged_1;
            // 
            // homeYellowbx
            // 
            homeYellowbx.BackColor = Color.FromArgb(248, 177, 121);
            homeYellowbx.Location = new Point(594, 0);
            homeYellowbx.Name = "homeYellowbx";
            homeYellowbx.Size = new Size(75, 5);
            homeYellowbx.TabIndex = 12;
            homeYellowbx.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.FromArgb(33, 46, 74);
            label7.FlatStyle = FlatStyle.Flat;
            label7.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.LightSteelBlue;
            label7.Location = new Point(35, 200);
            label7.Name = "label7";
            label7.Size = new Size(55, 13);
            label7.TabIndex = 11;
            label7.Text = "Password";
            // 
            // passtxtbx
            // 
            passtxtbx.BackColor = Color.FromArgb(33, 46, 74);
            passtxtbx.BorderStyle = BorderStyle.None;
            passtxtbx.Cursor = Cursors.Hand;
            passtxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            passtxtbx.ForeColor = Color.White;
            passtxtbx.Location = new Point(37, 222);
            passtxtbx.Name = "passtxtbx";
            passtxtbx.PasswordChar = '•';
            passtxtbx.RightToLeft = RightToLeft.No;
            passtxtbx.Size = new Size(296, 24);
            passtxtbx.TabIndex = 9;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox2.BackgroundImageLayout = ImageLayout.None;
            pictureBox2.Location = new Point(26, 197);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(307, 61);
            pictureBox2.TabIndex = 10;
            pictureBox2.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.FromArgb(33, 46, 74);
            label6.FlatStyle = FlatStyle.Flat;
            label6.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.LightSteelBlue;
            label6.Location = new Point(35, 129);
            label6.Name = "label6";
            label6.Size = new Size(57, 13);
            label6.TabIndex = 8;
            label6.Text = "Username";
            // 
            // usernametxtbx
            // 
            usernametxtbx.BackColor = Color.FromArgb(33, 46, 74);
            usernametxtbx.BorderStyle = BorderStyle.None;
            usernametxtbx.Cursor = Cursors.Hand;
            usernametxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            usernametxtbx.ForeColor = Color.White;
            usernametxtbx.Location = new Point(37, 151);
            usernametxtbx.Name = "usernametxtbx";
            usernametxtbx.RightToLeft = RightToLeft.No;
            usernametxtbx.Size = new Size(296, 24);
            usernametxtbx.TabIndex = 6;
            usernametxtbx.TextChanged += usernametxtbx_TextChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox1.BackgroundImageLayout = ImageLayout.None;
            pictureBox1.Location = new Point(26, 126);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(307, 61);
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(20, 44);
            label4.Name = "label4";
            label4.Size = new Size(189, 28);
            label4.TabIndex = 4;
            label4.Text = "Welcome Back";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.FlatStyle = FlatStyle.Flat;
            label5.Font = new Font("Century Gothic", 27.75F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.FromArgb(248, 177, 121);
            label5.Location = new Point(199, 32);
            label5.Name = "label5";
            label5.Size = new Size(29, 44);
            label5.TabIndex = 5;
            label5.Text = ".";
            // 
            // regpan
            // 
            regpan.Controls.Add(label21);
            regpan.Controls.Add(label20);
            regpan.Controls.Add(label19);
            regpan.Controls.Add(label14);
            regpan.Controls.Add(textBox6);
            regpan.Controls.Add(pictureBox9);
            regpan.Controls.Add(label13);
            regpan.Controls.Add(emtxtbx);
            regpan.Controls.Add(pictureBox8);
            regpan.Controls.Add(label12);
            regpan.Controls.Add(lntxtbx);
            regpan.Controls.Add(pictureBox7);
            regpan.Controls.Add(label11);
            regpan.Controls.Add(fntxtbx);
            regpan.Controls.Add(pictureBox6);
            regpan.Controls.Add(textBox5);
            regpan.Controls.Add(button4);
            regpan.Controls.Add(checkBox2);
            regpan.Controls.Add(pictureBox3);
            regpan.Controls.Add(label3);
            regpan.Controls.Add(textBox3);
            regpan.Controls.Add(pictureBox4);
            regpan.Controls.Add(label8);
            regpan.Controls.Add(textBox4);
            regpan.Controls.Add(pictureBox5);
            regpan.Controls.Add(label9);
            regpan.Controls.Add(label10);
            regpan.Location = new Point(32, 52);
            regpan.Name = "regpan";
            regpan.Size = new Size(750, 474);
            regpan.TabIndex = 15;
            regpan.Paint += regpan_Paint;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Cursor = Cursors.Hand;
            label21.FlatStyle = FlatStyle.Flat;
            label21.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label21.ForeColor = Color.FromArgb(248, 177, 121);
            label21.Location = new Point(198, 433);
            label21.Name = "label21";
            label21.RightToLeft = RightToLeft.No;
            label21.Size = new Size(43, 17);
            label21.TabIndex = 32;
            label21.Text = "Login";
            label21.Click += label21_Click;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.FlatStyle = FlatStyle.Flat;
            label20.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label20.ForeColor = Color.DarkGray;
            label20.Location = new Point(25, 433);
            label20.Name = "label20";
            label20.RightToLeft = RightToLeft.No;
            label20.Size = new Size(177, 17);
            label20.TabIndex = 31;
            label20.Text = "Already have an account.";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.FlatStyle = FlatStyle.Flat;
            label19.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label19.ForeColor = Color.DarkGray;
            label19.Location = new Point(25, 100);
            label19.Name = "label19";
            label19.RightToLeft = RightToLeft.No;
            label19.Size = new Size(331, 17);
            label19.TabIndex = 30;
            label19.Text = "Sign up now and become part of our community.";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.FromArgb(33, 46, 74);
            label14.FlatStyle = FlatStyle.Flat;
            label14.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label14.ForeColor = Color.LightSteelBlue;
            label14.Location = new Point(358, 265);
            label14.Name = "label14";
            label14.Size = new Size(96, 13);
            label14.TabIndex = 27;
            label14.Text = "Confirm Password";
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.FromArgb(33, 46, 74);
            textBox6.BorderStyle = BorderStyle.None;
            textBox6.Cursor = Cursors.Hand;
            textBox6.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.ForeColor = Color.White;
            textBox6.Location = new Point(360, 287);
            textBox6.Name = "textBox6";
            textBox6.PasswordChar = '•';
            textBox6.RightToLeft = RightToLeft.No;
            textBox6.Size = new Size(296, 24);
            textBox6.TabIndex = 25;
            textBox6.TextChanged += textBox6_TextChanged;
            // 
            // pictureBox9
            // 
            pictureBox9.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox9.BackgroundImageLayout = ImageLayout.None;
            pictureBox9.Location = new Point(349, 262);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(307, 61);
            pictureBox9.TabIndex = 26;
            pictureBox9.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.FromArgb(33, 46, 74);
            label13.FlatStyle = FlatStyle.Flat;
            label13.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = Color.LightSteelBlue;
            label13.Location = new Point(358, 196);
            label13.Name = "label13";
            label13.Size = new Size(34, 13);
            label13.TabIndex = 24;
            label13.Text = "Email";
            // 
            // emtxtbx
            // 
            emtxtbx.BackColor = Color.FromArgb(33, 46, 74);
            emtxtbx.BorderStyle = BorderStyle.None;
            emtxtbx.Cursor = Cursors.Hand;
            emtxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            emtxtbx.ForeColor = Color.White;
            emtxtbx.Location = new Point(360, 218);
            emtxtbx.Name = "emtxtbx";
            emtxtbx.RightToLeft = RightToLeft.No;
            emtxtbx.Size = new Size(296, 24);
            emtxtbx.TabIndex = 22;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox8.BackgroundImageLayout = ImageLayout.None;
            pictureBox8.Location = new Point(349, 193);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(307, 61);
            pictureBox8.TabIndex = 23;
            pictureBox8.TabStop = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.FromArgb(33, 46, 74);
            label12.FlatStyle = FlatStyle.Flat;
            label12.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.LightSteelBlue;
            label12.Location = new Point(358, 127);
            label12.Name = "label12";
            label12.Size = new Size(60, 13);
            label12.TabIndex = 21;
            label12.Text = "Last Name";
            // 
            // lntxtbx
            // 
            lntxtbx.BackColor = Color.FromArgb(33, 46, 74);
            lntxtbx.BorderStyle = BorderStyle.None;
            lntxtbx.Cursor = Cursors.Hand;
            lntxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lntxtbx.ForeColor = Color.White;
            lntxtbx.Location = new Point(360, 149);
            lntxtbx.Name = "lntxtbx";
            lntxtbx.RightToLeft = RightToLeft.No;
            lntxtbx.Size = new Size(296, 24);
            lntxtbx.TabIndex = 19;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox7.BackgroundImageLayout = ImageLayout.None;
            pictureBox7.Location = new Point(349, 124);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(307, 61);
            pictureBox7.TabIndex = 20;
            pictureBox7.TabStop = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.FromArgb(33, 46, 74);
            label11.FlatStyle = FlatStyle.Flat;
            label11.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.LightSteelBlue;
            label11.Location = new Point(34, 127);
            label11.Name = "label11";
            label11.Size = new Size(61, 13);
            label11.TabIndex = 18;
            label11.Text = "First Name";
            // 
            // fntxtbx
            // 
            fntxtbx.BackColor = Color.FromArgb(33, 46, 74);
            fntxtbx.BorderStyle = BorderStyle.None;
            fntxtbx.Cursor = Cursors.Hand;
            fntxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            fntxtbx.ForeColor = Color.White;
            fntxtbx.Location = new Point(36, 149);
            fntxtbx.Name = "fntxtbx";
            fntxtbx.RightToLeft = RightToLeft.No;
            fntxtbx.Size = new Size(296, 24);
            fntxtbx.TabIndex = 16;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox6.BackgroundImageLayout = ImageLayout.None;
            pictureBox6.Location = new Point(25, 124);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(307, 61);
            pictureBox6.TabIndex = 17;
            pictureBox6.TabStop = false;
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.FromArgb(22, 30, 49);
            textBox5.BorderStyle = BorderStyle.None;
            textBox5.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            textBox5.ForeColor = Color.DarkGray;
            textBox5.Location = new Point(25, 22);
            textBox5.Name = "textBox5";
            textBox5.RightToLeft = RightToLeft.No;
            textBox5.Size = new Size(226, 16);
            textBox5.TabIndex = 15;
            textBox5.Text = "START FOR FREE";
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(248, 177, 121);
            button4.BackgroundImageLayout = ImageLayout.None;
            button4.Cursor = Cursors.Hand;
            button4.FlatStyle = FlatStyle.Popup;
            button4.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button4.ForeColor = Color.FromArgb(22, 30, 49);
            button4.Location = new Point(25, 395);
            button4.Name = "button4";
            button4.Size = new Size(97, 28);
            button4.TabIndex = 14;
            button4.Text = "Join";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click_2;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.BackColor = Color.FromArgb(22, 30, 49);
            checkBox2.BackgroundImageLayout = ImageLayout.None;
            checkBox2.Cursor = Cursors.Hand;
            checkBox2.FlatStyle = FlatStyle.Flat;
            checkBox2.Font = new Font("Lato Semibold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox2.ForeColor = Color.LightSteelBlue;
            checkBox2.Location = new Point(26, 334);
            checkBox2.Name = "checkBox2";
            checkBox2.RightToLeft = RightToLeft.No;
            checkBox2.Size = new Size(113, 20);
            checkBox2.TabIndex = 13;
            checkBox2.Text = "Show Password";
            checkBox2.UseVisualStyleBackColor = false;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged_1;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.FromArgb(248, 177, 121);
            pictureBox3.Location = new Point(675, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(75, 5);
            pictureBox3.TabIndex = 12;
            pictureBox3.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(33, 46, 74);
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.LightSteelBlue;
            label3.Location = new Point(34, 265);
            label3.Name = "label3";
            label3.Size = new Size(55, 13);
            label3.TabIndex = 11;
            label3.Text = "Password";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(33, 46, 74);
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Cursor = Cursors.Hand;
            textBox3.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.ForeColor = Color.White;
            textBox3.Location = new Point(36, 287);
            textBox3.Name = "textBox3";
            textBox3.PasswordChar = '•';
            textBox3.RightToLeft = RightToLeft.No;
            textBox3.Size = new Size(296, 24);
            textBox3.TabIndex = 9;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox4.BackgroundImageLayout = ImageLayout.None;
            pictureBox4.Location = new Point(25, 262);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(307, 61);
            pictureBox4.TabIndex = 10;
            pictureBox4.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.FromArgb(33, 46, 74);
            label8.FlatStyle = FlatStyle.Flat;
            label8.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.LightSteelBlue;
            label8.Location = new Point(34, 196);
            label8.Name = "label8";
            label8.Size = new Size(57, 13);
            label8.TabIndex = 8;
            label8.Text = "Username";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.FromArgb(33, 46, 74);
            textBox4.BorderStyle = BorderStyle.None;
            textBox4.Cursor = Cursors.Hand;
            textBox4.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox4.ForeColor = Color.White;
            textBox4.Location = new Point(36, 218);
            textBox4.Name = "textBox4";
            textBox4.RightToLeft = RightToLeft.No;
            textBox4.Size = new Size(296, 24);
            textBox4.TabIndex = 6;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox5.BackgroundImageLayout = ImageLayout.None;
            pictureBox5.Location = new Point(25, 193);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(307, 61);
            pictureBox5.TabIndex = 7;
            pictureBox5.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.FlatStyle = FlatStyle.Flat;
            label9.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(19, 44);
            label9.Name = "label9";
            label9.Size = new Size(256, 28);
            label9.TabIndex = 4;
            label9.Text = "Create New Account";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.FlatStyle = FlatStyle.Flat;
            label10.Font = new Font("Century Gothic", 27.75F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.FromArgb(248, 177, 121);
            label10.Location = new Point(265, 32);
            label10.Name = "label10";
            label10.Size = new Size(29, 44);
            label10.TabIndex = 5;
            label10.Text = ".";
            // 
            // button1
            // 
            button1.BackgroundImageLayout = ImageLayout.None;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.DarkGray;
            button1.Location = new Point(626, 30);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 9;
            button1.Text = "Home";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.DarkGray;
            button2.Location = new Point(707, 30);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 10;
            button2.Text = "Join";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Pristina", 27.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(248, 177, 121);
            label2.Location = new Point(837, 542);
            label2.Name = "label2";
            label2.RightToLeft = RightToLeft.No;
            label2.Size = new Size(51, 49);
            label2.TabIndex = 14;
            label2.Text = "nx";
            label2.Click += label2_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Harlow Solid Italic", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(248, 177, 121);
            label1.Location = new Point(52, 529);
            label1.Name = "label1";
            label1.RightToLeft = RightToLeft.No;
            label1.Size = new Size(198, 26);
            label1.TabIndex = 0;
            label1.Text = "Unleash The Ride !";
            label1.Click += label1_Click;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(32, 19);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(52, 34);
            pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox10.TabIndex = 16;
            pictureBox10.TabStop = false;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.FlatStyle = FlatStyle.Flat;
            label15.Font = new Font("Palatino Linotype", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label15.ForeColor = Color.WhiteSmoke;
            label15.Location = new Point(90, 26);
            label15.Name = "label15";
            label15.RightToLeft = RightToLeft.No;
            label15.Size = new Size(99, 22);
            label15.TabIndex = 17;
            label15.Text = "NX Services";
            // 
            // button5
            // 
            button5.BackgroundImageLayout = ImageLayout.None;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Century Gothic", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            button5.ForeColor = Color.FromArgb(187, 150, 132);
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.Location = new Point(874, -1);
            button5.Name = "button5";
            button5.Size = new Size(25, 28);
            button5.TabIndex = 25;
            button5.TextImageRelation = TextImageRelation.TextBeforeImage;
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // UserLoginReg
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(22, 30, 49);
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(900, 600);
            Controls.Add(button5);
            Controls.Add(regpan);
            Controls.Add(label15);
            Controls.Add(pictureBox10);
            Controls.Add(label2);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(LoginPan);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            ForeColor = Color.White;
            FormBorderStyle = FormBorderStyle.None;
            Name = "UserLoginReg";
            RightToLeft = RightToLeft.Yes;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "UserLoginReg";
            Load += UserLoginReg_Load;
            LoginPan.ResumeLayout(false);
            LoginPan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)homeYellowbx).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            regpan.ResumeLayout(false);
            regpan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox usernametxtbx;
        private Panel LoginPan;
        private Label label4;
        private Label label5;
        private PictureBox pictureBox1;
        private Label label6;
        private Button button1;
        private Button button2;
        private CheckBox checkBox1;
        private PictureBox homeYellowbx;
        private Label label7;
        private TextBox passtxtbx;
        private PictureBox pictureBox2;
        private Button button3;
        private Panel regpan;
        private TextBox textBox5;
        private Button button4;
        private CheckBox checkBox2;
        private PictureBox pictureBox3;
        private Label label3;
        private TextBox textBox3;
        private PictureBox pictureBox4;
        private Label label8;
        private TextBox textBox4;
        private PictureBox pictureBox5;
        private Label label9;
        private Label label10;
        private Label label2;
        private Label label11;
        private TextBox fntxtbx;
        private PictureBox pictureBox6;
        private Label label14;
        private TextBox textBox6;
        private PictureBox pictureBox9;
        private Label label13;
        private TextBox emtxtbx;
        private PictureBox pictureBox8;
        private Label label12;
        private TextBox lntxtbx;
        private PictureBox pictureBox7;
        private Label label1;
        private PictureBox pictureBox10;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label21;
        private Label label20;
        private Label label19;
        private Button button5;
    }
}