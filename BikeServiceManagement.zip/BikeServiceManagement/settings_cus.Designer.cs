﻿namespace BikeServiceManagement
{
    partial class settings_cus
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label4 = new Label();
            pictureBox1 = new PictureBox();
            label6 = new Label();
            label14 = new Label();
            textBox6 = new TextBox();
            pictureBox9 = new PictureBox();
            label12 = new Label();
            lntxtbx = new TextBox();
            pictureBox7 = new PictureBox();
            label11 = new Label();
            fntxtbx = new TextBox();
            pictureBox6 = new PictureBox();
            label3 = new Label();
            textBox3 = new TextBox();
            pictureBox4 = new PictureBox();
            label13 = new Label();
            emtxtbx = new TextBox();
            pictureBox8 = new PictureBox();
            label8 = new Label();
            textBox4 = new TextBox();
            pictureBox5 = new PictureBox();
            label1 = new Label();
            button2 = new Button();
            checkBox2 = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(25, 35, 57);
            label4.Font = new Font("Century Gothic", 12.75F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(187, 150, 132);
            label4.Location = new Point(14, 16);
            label4.Name = "label4";
            label4.Size = new Size(82, 19);
            label4.TabIndex = 28;
            label4.Text = "SETTINGS";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(25, 35, 57);
            pictureBox1.Dock = DockStyle.Top;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(691, 50);
            pictureBox1.TabIndex = 27;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.FlatStyle = FlatStyle.Flat;
            label6.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.LightGray;
            label6.Location = new Point(14, 66);
            label6.Name = "label6";
            label6.Size = new Size(120, 19);
            label6.TabIndex = 29;
            label6.Text = "Update Profile ";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.FromArgb(33, 46, 74);
            label14.FlatStyle = FlatStyle.Flat;
            label14.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label14.ForeColor = Color.LightSteelBlue;
            label14.Location = new Point(363, 250);
            label14.Name = "label14";
            label14.Size = new Size(96, 13);
            label14.TabIndex = 47;
            label14.Text = "Confirm Password";
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.FromArgb(33, 46, 74);
            textBox6.BorderStyle = BorderStyle.None;
            textBox6.Cursor = Cursors.Hand;
            textBox6.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.ForeColor = Color.White;
            textBox6.Location = new Point(365, 272);
            textBox6.Name = "textBox6";
            textBox6.PasswordChar = '•';
            textBox6.RightToLeft = RightToLeft.No;
            textBox6.Size = new Size(296, 24);
            textBox6.TabIndex = 45;
            // 
            // pictureBox9
            // 
            pictureBox9.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox9.BackgroundImageLayout = ImageLayout.None;
            pictureBox9.Location = new Point(354, 247);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(307, 61);
            pictureBox9.TabIndex = 46;
            pictureBox9.TabStop = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.FromArgb(33, 46, 74);
            label12.FlatStyle = FlatStyle.Flat;
            label12.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.LightSteelBlue;
            label12.Location = new Point(363, 183);
            label12.Name = "label12";
            label12.Size = new Size(60, 13);
            label12.TabIndex = 41;
            label12.Text = "Last Name";
            // 
            // lntxtbx
            // 
            lntxtbx.BackColor = Color.FromArgb(33, 46, 74);
            lntxtbx.BorderStyle = BorderStyle.None;
            lntxtbx.Cursor = Cursors.Hand;
            lntxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lntxtbx.ForeColor = Color.White;
            lntxtbx.Location = new Point(365, 205);
            lntxtbx.Name = "lntxtbx";
            lntxtbx.RightToLeft = RightToLeft.No;
            lntxtbx.Size = new Size(296, 24);
            lntxtbx.TabIndex = 39;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox7.BackgroundImageLayout = ImageLayout.None;
            pictureBox7.Location = new Point(354, 180);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(307, 61);
            pictureBox7.TabIndex = 40;
            pictureBox7.TabStop = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.FromArgb(33, 46, 74);
            label11.FlatStyle = FlatStyle.Flat;
            label11.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.LightSteelBlue;
            label11.Location = new Point(39, 183);
            label11.Name = "label11";
            label11.Size = new Size(61, 13);
            label11.TabIndex = 38;
            label11.Text = "First Name";
            // 
            // fntxtbx
            // 
            fntxtbx.BackColor = Color.FromArgb(33, 46, 74);
            fntxtbx.BorderStyle = BorderStyle.None;
            fntxtbx.Cursor = Cursors.Hand;
            fntxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            fntxtbx.ForeColor = Color.White;
            fntxtbx.Location = new Point(41, 205);
            fntxtbx.Name = "fntxtbx";
            fntxtbx.RightToLeft = RightToLeft.No;
            fntxtbx.Size = new Size(296, 24);
            fntxtbx.TabIndex = 36;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox6.BackgroundImageLayout = ImageLayout.None;
            pictureBox6.Location = new Point(30, 180);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(307, 61);
            pictureBox6.TabIndex = 37;
            pictureBox6.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(33, 46, 74);
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.LightSteelBlue;
            label3.Location = new Point(39, 250);
            label3.Name = "label3";
            label3.Size = new Size(81, 13);
            label3.TabIndex = 35;
            label3.Text = "New Password";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(33, 46, 74);
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Cursor = Cursors.Hand;
            textBox3.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.ForeColor = Color.White;
            textBox3.Location = new Point(41, 272);
            textBox3.Name = "textBox3";
            textBox3.PasswordChar = '•';
            textBox3.RightToLeft = RightToLeft.No;
            textBox3.Size = new Size(296, 24);
            textBox3.TabIndex = 33;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox4.BackgroundImageLayout = ImageLayout.None;
            pictureBox4.Location = new Point(30, 247);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(307, 61);
            pictureBox4.TabIndex = 34;
            pictureBox4.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.FromArgb(33, 46, 74);
            label13.FlatStyle = FlatStyle.Flat;
            label13.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = Color.LightSteelBlue;
            label13.Location = new Point(363, 116);
            label13.Name = "label13";
            label13.Size = new Size(34, 13);
            label13.TabIndex = 53;
            label13.Text = "Email";
            // 
            // emtxtbx
            // 
            emtxtbx.BackColor = Color.FromArgb(33, 46, 74);
            emtxtbx.BorderStyle = BorderStyle.None;
            emtxtbx.Cursor = Cursors.Hand;
            emtxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            emtxtbx.ForeColor = Color.White;
            emtxtbx.Location = new Point(365, 138);
            emtxtbx.Name = "emtxtbx";
            emtxtbx.RightToLeft = RightToLeft.No;
            emtxtbx.Size = new Size(296, 24);
            emtxtbx.TabIndex = 51;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox8.BackgroundImageLayout = ImageLayout.None;
            pictureBox8.Location = new Point(354, 113);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(307, 61);
            pictureBox8.TabIndex = 52;
            pictureBox8.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.FromArgb(33, 46, 74);
            label8.FlatStyle = FlatStyle.Flat;
            label8.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.LightSteelBlue;
            label8.Location = new Point(39, 116);
            label8.Name = "label8";
            label8.Size = new Size(83, 13);
            label8.TabIndex = 50;
            label8.Text = "New Username";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.FromArgb(33, 46, 74);
            textBox4.BorderStyle = BorderStyle.None;
            textBox4.Cursor = Cursors.Hand;
            textBox4.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox4.ForeColor = Color.White;
            textBox4.Location = new Point(41, 138);
            textBox4.Name = "textBox4";
            textBox4.RightToLeft = RightToLeft.No;
            textBox4.Size = new Size(296, 24);
            textBox4.TabIndex = 48;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox5.BackgroundImageLayout = ImageLayout.None;
            pictureBox5.Location = new Point(30, 113);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(307, 61);
            pictureBox5.TabIndex = 49;
            pictureBox5.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Gray;
            label1.Location = new Point(140, 68);
            label1.Name = "label1";
            label1.Size = new Size(285, 16);
            label1.TabIndex = 54;
            label1.Text = "(Leave empty if you don't want to change) ";
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(248, 177, 121);
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.FromArgb(22, 30, 49);
            button2.Location = new Point(296, 367);
            button2.Name = "button2";
            button2.Size = new Size(97, 28);
            button2.TabIndex = 55;
            button2.Text = "Confirm";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.BackColor = Color.FromArgb(22, 30, 49);
            checkBox2.BackgroundImageLayout = ImageLayout.None;
            checkBox2.Cursor = Cursors.Hand;
            checkBox2.FlatStyle = FlatStyle.Flat;
            checkBox2.Font = new Font("Lato Semibold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox2.ForeColor = Color.LightSteelBlue;
            checkBox2.Location = new Point(30, 320);
            checkBox2.Name = "checkBox2";
            checkBox2.RightToLeft = RightToLeft.No;
            checkBox2.Size = new Size(113, 20);
            checkBox2.TabIndex = 56;
            checkBox2.Text = "Show Password";
            checkBox2.UseVisualStyleBackColor = false;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // settings_cus
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(22, 30, 49);
            Controls.Add(checkBox2);
            Controls.Add(button2);
            Controls.Add(label1);
            Controls.Add(label13);
            Controls.Add(emtxtbx);
            Controls.Add(pictureBox8);
            Controls.Add(label8);
            Controls.Add(textBox4);
            Controls.Add(pictureBox5);
            Controls.Add(label14);
            Controls.Add(textBox6);
            Controls.Add(pictureBox9);
            Controls.Add(label12);
            Controls.Add(lntxtbx);
            Controls.Add(pictureBox7);
            Controls.Add(label11);
            Controls.Add(fntxtbx);
            Controls.Add(pictureBox6);
            Controls.Add(label3);
            Controls.Add(textBox3);
            Controls.Add(pictureBox4);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(pictureBox1);
            Name = "settings_cus";
            Size = new Size(691, 540);
            Load += settings_cus_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label4;
        private PictureBox pictureBox1;
        private Label label6;
        private Label label14;
        private TextBox textBox6;
        private PictureBox pictureBox9;
        private Label label12;
        private TextBox lntxtbx;
        private PictureBox pictureBox7;
        private Label label11;
        private TextBox fntxtbx;
        private PictureBox pictureBox6;
        private Label label3;
        private TextBox textBox3;
        private PictureBox pictureBox4;
        private Label label13;
        private TextBox emtxtbx;
        private PictureBox pictureBox8;
        private Label label8;
        private TextBox textBox4;
        private PictureBox pictureBox5;
        private Label label1;
        private Button button2;
        private CheckBox checkBox2;
    }
}
