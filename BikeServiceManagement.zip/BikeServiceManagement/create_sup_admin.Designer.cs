﻿namespace BikeServiceManagement
{
    partial class create_sup_admin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label4 = new Label();
            pictureBox1 = new PictureBox();
            addSrvcBtn = new Button();
            addUsrBtn = new Button();
            addusrpan = new Panel();
            usrRoleComboBox = new ComboBox();
            label14 = new Label();
            textBox6 = new TextBox();
            pictureBox9 = new PictureBox();
            label13 = new Label();
            emtxtbx = new TextBox();
            pictureBox8 = new PictureBox();
            label12 = new Label();
            lntxtbx = new TextBox();
            pictureBox7 = new PictureBox();
            label11 = new Label();
            fntxtbx = new TextBox();
            pictureBox6 = new PictureBox();
            button4 = new Button();
            checkBox2 = new CheckBox();
            label3 = new Label();
            textBox3 = new TextBox();
            pictureBox4 = new PictureBox();
            label8 = new Label();
            textBox4 = new TextBox();
            pictureBox5 = new PictureBox();
            pictureBox3 = new PictureBox();
            addsrvcpan = new Panel();
            label5 = new Label();
            label2 = new Label();
            label1 = new Label();
            button2 = new Button();
            price_bx = new TextBox();
            pictureBox10 = new PictureBox();
            sn_box = new TextBox();
            pictureBox11 = new PictureBox();
            comboBox2 = new ComboBox();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            addusrpan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            addsrvcpan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(25, 35, 57);
            label4.Font = new Font("Century Gothic", 12.75F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(187, 150, 132);
            label4.Location = new Point(14, 16);
            label4.Name = "label4";
            label4.Size = new Size(70, 19);
            label4.TabIndex = 30;
            label4.Text = "CREATE";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(25, 35, 57);
            pictureBox1.Dock = DockStyle.Top;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(691, 50);
            pictureBox1.TabIndex = 29;
            pictureBox1.TabStop = false;
            // 
            // addSrvcBtn
            // 
            addSrvcBtn.BackgroundImageLayout = ImageLayout.None;
            addSrvcBtn.Cursor = Cursors.Hand;
            addSrvcBtn.FlatStyle = FlatStyle.Flat;
            addSrvcBtn.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            addSrvcBtn.ForeColor = Color.DarkGray;
            addSrvcBtn.Location = new Point(169, 54);
            addSrvcBtn.Name = "addSrvcBtn";
            addSrvcBtn.Size = new Size(160, 23);
            addSrvcBtn.TabIndex = 32;
            addSrvcBtn.Text = "Add Services";
            addSrvcBtn.UseVisualStyleBackColor = true;
            addSrvcBtn.Click += addSrvcBtn_Click;
            // 
            // addUsrBtn
            // 
            addUsrBtn.BackgroundImageLayout = ImageLayout.None;
            addUsrBtn.Cursor = Cursors.Hand;
            addUsrBtn.FlatStyle = FlatStyle.Flat;
            addUsrBtn.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            addUsrBtn.ForeColor = Color.DarkGray;
            addUsrBtn.Location = new Point(3, 54);
            addUsrBtn.Name = "addUsrBtn";
            addUsrBtn.Size = new Size(160, 23);
            addUsrBtn.TabIndex = 31;
            addUsrBtn.Text = "Add Users";
            addUsrBtn.UseVisualStyleBackColor = true;
            addUsrBtn.Click += addUsrBtn_Click;
            // 
            // addusrpan
            // 
            addusrpan.Controls.Add(usrRoleComboBox);
            addusrpan.Controls.Add(label14);
            addusrpan.Controls.Add(textBox6);
            addusrpan.Controls.Add(pictureBox9);
            addusrpan.Controls.Add(label13);
            addusrpan.Controls.Add(emtxtbx);
            addusrpan.Controls.Add(pictureBox8);
            addusrpan.Controls.Add(label12);
            addusrpan.Controls.Add(lntxtbx);
            addusrpan.Controls.Add(pictureBox7);
            addusrpan.Controls.Add(label11);
            addusrpan.Controls.Add(fntxtbx);
            addusrpan.Controls.Add(pictureBox6);
            addusrpan.Controls.Add(button4);
            addusrpan.Controls.Add(checkBox2);
            addusrpan.Controls.Add(label3);
            addusrpan.Controls.Add(textBox3);
            addusrpan.Controls.Add(pictureBox4);
            addusrpan.Controls.Add(label8);
            addusrpan.Controls.Add(textBox4);
            addusrpan.Controls.Add(pictureBox5);
            addusrpan.Controls.Add(pictureBox3);
            addusrpan.Location = new Point(3, 77);
            addusrpan.Name = "addusrpan";
            addusrpan.Size = new Size(685, 460);
            addusrpan.TabIndex = 33;
            // 
            // usrRoleComboBox
            // 
            usrRoleComboBox.BackColor = Color.FromArgb(33, 46, 74);
            usrRoleComboBox.Cursor = Cursors.Hand;
            usrRoleComboBox.FlatStyle = FlatStyle.Flat;
            usrRoleComboBox.Font = new Font("Lato Semibold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point);
            usrRoleComboBox.ForeColor = Color.LightSteelBlue;
            usrRoleComboBox.FormattingEnabled = true;
            usrRoleComboBox.Items.AddRange(new object[] { "Customer", "Admin", "SuperAdmin" });
            usrRoleComboBox.Location = new Point(28, 22);
            usrRoleComboBox.Name = "usrRoleComboBox";
            usrRoleComboBox.Size = new Size(306, 24);
            usrRoleComboBox.TabIndex = 48;
            usrRoleComboBox.Text = " User Role";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.FromArgb(33, 46, 74);
            label14.FlatStyle = FlatStyle.Flat;
            label14.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label14.ForeColor = Color.LightSteelBlue;
            label14.Location = new Point(360, 212);
            label14.Name = "label14";
            label14.Size = new Size(96, 13);
            label14.TabIndex = 47;
            label14.Text = "Confirm Password";
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.FromArgb(33, 46, 74);
            textBox6.BorderStyle = BorderStyle.None;
            textBox6.Cursor = Cursors.Hand;
            textBox6.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.ForeColor = Color.White;
            textBox6.Location = new Point(362, 234);
            textBox6.Name = "textBox6";
            textBox6.PasswordChar = '•';
            textBox6.RightToLeft = RightToLeft.No;
            textBox6.Size = new Size(296, 24);
            textBox6.TabIndex = 45;
            // 
            // pictureBox9
            // 
            pictureBox9.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox9.BackgroundImageLayout = ImageLayout.None;
            pictureBox9.Location = new Point(351, 209);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(307, 61);
            pictureBox9.TabIndex = 46;
            pictureBox9.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.FromArgb(33, 46, 74);
            label13.FlatStyle = FlatStyle.Flat;
            label13.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = Color.LightSteelBlue;
            label13.Location = new Point(360, 143);
            label13.Name = "label13";
            label13.Size = new Size(34, 13);
            label13.TabIndex = 44;
            label13.Text = "Email";
            // 
            // emtxtbx
            // 
            emtxtbx.BackColor = Color.FromArgb(33, 46, 74);
            emtxtbx.BorderStyle = BorderStyle.None;
            emtxtbx.Cursor = Cursors.Hand;
            emtxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            emtxtbx.ForeColor = Color.White;
            emtxtbx.Location = new Point(362, 165);
            emtxtbx.Name = "emtxtbx";
            emtxtbx.RightToLeft = RightToLeft.No;
            emtxtbx.Size = new Size(296, 24);
            emtxtbx.TabIndex = 42;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox8.BackgroundImageLayout = ImageLayout.None;
            pictureBox8.Location = new Point(351, 140);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(307, 61);
            pictureBox8.TabIndex = 43;
            pictureBox8.TabStop = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.FromArgb(33, 46, 74);
            label12.FlatStyle = FlatStyle.Flat;
            label12.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.LightSteelBlue;
            label12.Location = new Point(360, 74);
            label12.Name = "label12";
            label12.Size = new Size(60, 13);
            label12.TabIndex = 41;
            label12.Text = "Last Name";
            // 
            // lntxtbx
            // 
            lntxtbx.BackColor = Color.FromArgb(33, 46, 74);
            lntxtbx.BorderStyle = BorderStyle.None;
            lntxtbx.Cursor = Cursors.Hand;
            lntxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lntxtbx.ForeColor = Color.White;
            lntxtbx.Location = new Point(362, 96);
            lntxtbx.Name = "lntxtbx";
            lntxtbx.RightToLeft = RightToLeft.No;
            lntxtbx.Size = new Size(296, 24);
            lntxtbx.TabIndex = 39;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox7.BackgroundImageLayout = ImageLayout.None;
            pictureBox7.Location = new Point(351, 71);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(307, 61);
            pictureBox7.TabIndex = 40;
            pictureBox7.TabStop = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.FromArgb(33, 46, 74);
            label11.FlatStyle = FlatStyle.Flat;
            label11.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.LightSteelBlue;
            label11.Location = new Point(36, 74);
            label11.Name = "label11";
            label11.Size = new Size(61, 13);
            label11.TabIndex = 38;
            label11.Text = "First Name";
            // 
            // fntxtbx
            // 
            fntxtbx.BackColor = Color.FromArgb(33, 46, 74);
            fntxtbx.BorderStyle = BorderStyle.None;
            fntxtbx.Cursor = Cursors.Hand;
            fntxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            fntxtbx.ForeColor = Color.White;
            fntxtbx.Location = new Point(38, 96);
            fntxtbx.Name = "fntxtbx";
            fntxtbx.RightToLeft = RightToLeft.No;
            fntxtbx.Size = new Size(296, 24);
            fntxtbx.TabIndex = 36;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox6.BackgroundImageLayout = ImageLayout.None;
            pictureBox6.Location = new Point(27, 71);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(307, 61);
            pictureBox6.TabIndex = 37;
            pictureBox6.TabStop = false;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(248, 177, 121);
            button4.BackgroundImageLayout = ImageLayout.None;
            button4.Cursor = Cursors.Hand;
            button4.FlatStyle = FlatStyle.Popup;
            button4.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button4.ForeColor = Color.FromArgb(22, 30, 49);
            button4.Location = new Point(27, 322);
            button4.Name = "button4";
            button4.Size = new Size(97, 28);
            button4.TabIndex = 35;
            button4.Text = "Add";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.BackColor = Color.FromArgb(22, 30, 49);
            checkBox2.BackgroundImageLayout = ImageLayout.None;
            checkBox2.Cursor = Cursors.Hand;
            checkBox2.FlatStyle = FlatStyle.Flat;
            checkBox2.Font = new Font("Lato Semibold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox2.ForeColor = Color.LightSteelBlue;
            checkBox2.Location = new Point(28, 281);
            checkBox2.Name = "checkBox2";
            checkBox2.RightToLeft = RightToLeft.No;
            checkBox2.Size = new Size(113, 20);
            checkBox2.TabIndex = 34;
            checkBox2.Text = "Show Password";
            checkBox2.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(33, 46, 74);
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.LightSteelBlue;
            label3.Location = new Point(36, 212);
            label3.Name = "label3";
            label3.Size = new Size(55, 13);
            label3.TabIndex = 33;
            label3.Text = "Password";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(33, 46, 74);
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Cursor = Cursors.Hand;
            textBox3.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.ForeColor = Color.White;
            textBox3.Location = new Point(38, 234);
            textBox3.Name = "textBox3";
            textBox3.PasswordChar = '•';
            textBox3.RightToLeft = RightToLeft.No;
            textBox3.Size = new Size(296, 24);
            textBox3.TabIndex = 31;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox4.BackgroundImageLayout = ImageLayout.None;
            pictureBox4.Location = new Point(27, 209);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(307, 61);
            pictureBox4.TabIndex = 32;
            pictureBox4.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.FromArgb(33, 46, 74);
            label8.FlatStyle = FlatStyle.Flat;
            label8.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.LightSteelBlue;
            label8.Location = new Point(36, 143);
            label8.Name = "label8";
            label8.Size = new Size(57, 13);
            label8.TabIndex = 30;
            label8.Text = "Username";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.FromArgb(33, 46, 74);
            textBox4.BorderStyle = BorderStyle.None;
            textBox4.Cursor = Cursors.Hand;
            textBox4.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox4.ForeColor = Color.White;
            textBox4.Location = new Point(38, 165);
            textBox4.Name = "textBox4";
            textBox4.RightToLeft = RightToLeft.No;
            textBox4.Size = new Size(296, 24);
            textBox4.TabIndex = 28;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox5.BackgroundImageLayout = ImageLayout.None;
            pictureBox5.Location = new Point(27, 140);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(307, 61);
            pictureBox5.TabIndex = 29;
            pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.FromArgb(248, 177, 121);
            pictureBox3.Location = new Point(0, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(160, 3);
            pictureBox3.TabIndex = 13;
            pictureBox3.TabStop = false;
            // 
            // addsrvcpan
            // 
            addsrvcpan.Controls.Add(label5);
            addsrvcpan.Controls.Add(label2);
            addsrvcpan.Controls.Add(label1);
            addsrvcpan.Controls.Add(button2);
            addsrvcpan.Controls.Add(price_bx);
            addsrvcpan.Controls.Add(pictureBox10);
            addsrvcpan.Controls.Add(sn_box);
            addsrvcpan.Controls.Add(pictureBox11);
            addsrvcpan.Controls.Add(comboBox2);
            addsrvcpan.Controls.Add(pictureBox2);
            addsrvcpan.Location = new Point(4, 77);
            addsrvcpan.Name = "addsrvcpan";
            addsrvcpan.Size = new Size(685, 460);
            addsrvcpan.TabIndex = 34;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.FlatStyle = FlatStyle.Flat;
            label5.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.DarkGray;
            label5.Location = new Point(27, 33);
            label5.Name = "label5";
            label5.Size = new Size(111, 16);
            label5.TabIndex = 71;
            label5.Text = "Service Provider";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.DarkGray;
            label2.Location = new Point(351, 121);
            label2.Name = "label2";
            label2.Size = new Size(39, 16);
            label2.TabIndex = 70;
            label2.Text = "Price";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.DarkGray;
            label1.Location = new Point(27, 121);
            label1.Name = "label1";
            label1.Size = new Size(97, 16);
            label1.TabIndex = 69;
            label1.Text = "Service Name";
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(248, 177, 121);
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.FromArgb(22, 30, 49);
            button2.Location = new Point(297, 294);
            button2.Name = "button2";
            button2.Size = new Size(97, 28);
            button2.TabIndex = 68;
            button2.Text = "Confirm";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // price_bx
            // 
            price_bx.BackColor = Color.FromArgb(33, 46, 74);
            price_bx.BorderStyle = BorderStyle.None;
            price_bx.Cursor = Cursors.Hand;
            price_bx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            price_bx.ForeColor = Color.White;
            price_bx.Location = new Point(362, 176);
            price_bx.Name = "price_bx";
            price_bx.RightToLeft = RightToLeft.No;
            price_bx.Size = new Size(296, 24);
            price_bx.TabIndex = 66;
            // 
            // pictureBox10
            // 
            pictureBox10.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox10.BackgroundImageLayout = ImageLayout.None;
            pictureBox10.Location = new Point(351, 151);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(307, 61);
            pictureBox10.TabIndex = 67;
            pictureBox10.TabStop = false;
            // 
            // sn_box
            // 
            sn_box.BackColor = Color.FromArgb(33, 46, 74);
            sn_box.BorderStyle = BorderStyle.None;
            sn_box.Cursor = Cursors.Hand;
            sn_box.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            sn_box.ForeColor = Color.White;
            sn_box.Location = new Point(38, 176);
            sn_box.Name = "sn_box";
            sn_box.RightToLeft = RightToLeft.No;
            sn_box.Size = new Size(296, 24);
            sn_box.TabIndex = 64;
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox11.BackgroundImageLayout = ImageLayout.None;
            pictureBox11.Location = new Point(27, 151);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(307, 61);
            pictureBox11.TabIndex = 65;
            pictureBox11.TabStop = false;
            // 
            // comboBox2
            // 
            comboBox2.BackColor = Color.FromArgb(33, 46, 74);
            comboBox2.Cursor = Cursors.Hand;
            comboBox2.FlatStyle = FlatStyle.Flat;
            comboBox2.Font = new Font("Lato Semibold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point);
            comboBox2.ForeColor = Color.LightSteelBlue;
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(27, 64);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(307, 24);
            comboBox2.TabIndex = 22;
            comboBox2.Text = " Service Provider";
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(248, 177, 121);
            pictureBox2.Location = new Point(165, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(160, 3);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 14;
            pictureBox2.TabStop = false;
            // 
            // create_sup_admin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(22, 30, 49);
            Controls.Add(addsrvcpan);
            Controls.Add(addusrpan);
            Controls.Add(addSrvcBtn);
            Controls.Add(addUsrBtn);
            Controls.Add(label4);
            Controls.Add(pictureBox1);
            Name = "create_sup_admin";
            Size = new Size(691, 540);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            addusrpan.ResumeLayout(false);
            addusrpan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            addsrvcpan.ResumeLayout(false);
            addsrvcpan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label4;
        private PictureBox pictureBox1;
        private Button addSrvcBtn;
        private Button addUsrBtn;
        private Panel addusrpan;
        private PictureBox pictureBox3;
        private Label label14;
        private TextBox textBox6;
        private PictureBox pictureBox9;
        private Label label13;
        private TextBox emtxtbx;
        private PictureBox pictureBox8;
        private Label label12;
        private TextBox lntxtbx;
        private PictureBox pictureBox7;
        private Label label11;
        private TextBox fntxtbx;
        private PictureBox pictureBox6;
        private Button button4;
        private CheckBox checkBox2;
        private Label label3;
        private TextBox textBox3;
        private PictureBox pictureBox4;
        private Label label8;
        private TextBox textBox4;
        private PictureBox pictureBox5;
        private ComboBox usrRoleComboBox;
        private Panel addsrvcpan;
        private PictureBox pictureBox2;
        private ComboBox comboBox2;
        private Label label2;
        private Label label1;
        private Button button2;
        private TextBox price_bx;
        private PictureBox pictureBox10;
        private TextBox sn_box;
        private PictureBox pictureBox11;
        private Label label5;
    }
}
