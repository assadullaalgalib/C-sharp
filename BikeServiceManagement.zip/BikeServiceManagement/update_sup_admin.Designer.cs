﻿namespace BikeServiceManagement
{
    partial class update_sup_admin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label4 = new Label();
            pictureBox1 = new PictureBox();
            updtSrvcBtn = new Button();
            updtUsrBtn = new Button();
            updtSrvcpan = new Panel();
            label5 = new Label();
            label2 = new Label();
            label1 = new Label();
            button2 = new Button();
            price_bx = new TextBox();
            pictureBox10 = new PictureBox();
            sn_box = new TextBox();
            pictureBox11 = new PictureBox();
            comboBox2 = new ComboBox();
            pictureBox2 = new PictureBox();
            updtUsrpan = new Panel();
            label7 = new Label();
            textBox2 = new TextBox();
            pictureBox13 = new PictureBox();
            label6 = new Label();
            textBox1 = new TextBox();
            pictureBox12 = new PictureBox();
            checkBox2 = new CheckBox();
            button1 = new Button();
            label13 = new Label();
            emtxtbx = new TextBox();
            pictureBox8 = new PictureBox();
            label8 = new Label();
            textBox4 = new TextBox();
            pictureBox5 = new PictureBox();
            label14 = new Label();
            textBox6 = new TextBox();
            pictureBox9 = new PictureBox();
            label12 = new Label();
            lntxtbx = new TextBox();
            pictureBox7 = new PictureBox();
            label11 = new Label();
            fntxtbx = new TextBox();
            pictureBox6 = new PictureBox();
            label3 = new Label();
            textBox3 = new TextBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            updtSrvcpan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            updtUsrpan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(25, 35, 57);
            label4.Font = new Font("Century Gothic", 12.75F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(187, 150, 132);
            label4.Location = new Point(14, 16);
            label4.Name = "label4";
            label4.Size = new Size(70, 19);
            label4.TabIndex = 32;
            label4.Text = "UPDATE";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(25, 35, 57);
            pictureBox1.Dock = DockStyle.Top;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(691, 50);
            pictureBox1.TabIndex = 31;
            pictureBox1.TabStop = false;
            // 
            // updtSrvcBtn
            // 
            updtSrvcBtn.BackgroundImageLayout = ImageLayout.None;
            updtSrvcBtn.Cursor = Cursors.Hand;
            updtSrvcBtn.FlatStyle = FlatStyle.Flat;
            updtSrvcBtn.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            updtSrvcBtn.ForeColor = Color.DarkGray;
            updtSrvcBtn.Location = new Point(169, 54);
            updtSrvcBtn.Name = "updtSrvcBtn";
            updtSrvcBtn.Size = new Size(160, 23);
            updtSrvcBtn.TabIndex = 34;
            updtSrvcBtn.Text = "Update Services";
            updtSrvcBtn.UseVisualStyleBackColor = true;
            updtSrvcBtn.Click += updtSrvcBtn_Click;
            // 
            // updtUsrBtn
            // 
            updtUsrBtn.BackgroundImageLayout = ImageLayout.None;
            updtUsrBtn.Cursor = Cursors.Hand;
            updtUsrBtn.FlatStyle = FlatStyle.Flat;
            updtUsrBtn.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            updtUsrBtn.ForeColor = Color.DarkGray;
            updtUsrBtn.Location = new Point(3, 54);
            updtUsrBtn.Name = "updtUsrBtn";
            updtUsrBtn.Size = new Size(160, 23);
            updtUsrBtn.TabIndex = 33;
            updtUsrBtn.Text = "Update Users";
            updtUsrBtn.UseVisualStyleBackColor = true;
            updtUsrBtn.Click += updtUsrBtn_Click;
            // 
            // updtSrvcpan
            // 
            updtSrvcpan.Controls.Add(label5);
            updtSrvcpan.Controls.Add(label2);
            updtSrvcpan.Controls.Add(label1);
            updtSrvcpan.Controls.Add(button2);
            updtSrvcpan.Controls.Add(price_bx);
            updtSrvcpan.Controls.Add(pictureBox10);
            updtSrvcpan.Controls.Add(sn_box);
            updtSrvcpan.Controls.Add(pictureBox11);
            updtSrvcpan.Controls.Add(comboBox2);
            updtSrvcpan.Controls.Add(pictureBox2);
            updtSrvcpan.Location = new Point(3, 77);
            updtSrvcpan.Name = "updtSrvcpan";
            updtSrvcpan.Size = new Size(685, 459);
            updtSrvcpan.TabIndex = 35;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.FlatStyle = FlatStyle.Flat;
            label5.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.DarkGray;
            label5.Location = new Point(27, 33);
            label5.Name = "label5";
            label5.Size = new Size(111, 16);
            label5.TabIndex = 80;
            label5.Text = "Service Provider";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.DarkGray;
            label2.Location = new Point(351, 121);
            label2.Name = "label2";
            label2.Size = new Size(39, 16);
            label2.TabIndex = 79;
            label2.Text = "Price";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.DarkGray;
            label1.Location = new Point(27, 121);
            label1.Name = "label1";
            label1.Size = new Size(97, 16);
            label1.TabIndex = 78;
            label1.Text = "Service Name";
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(248, 177, 121);
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.FromArgb(22, 30, 49);
            button2.Location = new Point(297, 294);
            button2.Name = "button2";
            button2.Size = new Size(97, 28);
            button2.TabIndex = 77;
            button2.Text = "Confirm";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // price_bx
            // 
            price_bx.BackColor = Color.FromArgb(33, 46, 74);
            price_bx.BorderStyle = BorderStyle.None;
            price_bx.Cursor = Cursors.Hand;
            price_bx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            price_bx.ForeColor = Color.White;
            price_bx.Location = new Point(362, 176);
            price_bx.Name = "price_bx";
            price_bx.RightToLeft = RightToLeft.No;
            price_bx.Size = new Size(296, 24);
            price_bx.TabIndex = 75;
            // 
            // pictureBox10
            // 
            pictureBox10.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox10.BackgroundImageLayout = ImageLayout.None;
            pictureBox10.Location = new Point(351, 151);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(307, 61);
            pictureBox10.TabIndex = 76;
            pictureBox10.TabStop = false;
            // 
            // sn_box
            // 
            sn_box.BackColor = Color.FromArgb(33, 46, 74);
            sn_box.BorderStyle = BorderStyle.None;
            sn_box.Cursor = Cursors.Hand;
            sn_box.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            sn_box.ForeColor = Color.White;
            sn_box.Location = new Point(38, 176);
            sn_box.Name = "sn_box";
            sn_box.RightToLeft = RightToLeft.No;
            sn_box.Size = new Size(296, 24);
            sn_box.TabIndex = 73;
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox11.BackgroundImageLayout = ImageLayout.None;
            pictureBox11.Location = new Point(27, 151);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(307, 61);
            pictureBox11.TabIndex = 74;
            pictureBox11.TabStop = false;
            // 
            // comboBox2
            // 
            comboBox2.BackColor = Color.FromArgb(33, 46, 74);
            comboBox2.Cursor = Cursors.Hand;
            comboBox2.FlatStyle = FlatStyle.Flat;
            comboBox2.Font = new Font("Lato Semibold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point);
            comboBox2.ForeColor = Color.LightSteelBlue;
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(27, 64);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(307, 24);
            comboBox2.TabIndex = 72;
            comboBox2.Text = " Service Provider";
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(248, 177, 121);
            pictureBox2.Location = new Point(166, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(160, 3);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 15;
            pictureBox2.TabStop = false;
            // 
            // updtUsrpan
            // 
            updtUsrpan.Controls.Add(label7);
            updtUsrpan.Controls.Add(textBox2);
            updtUsrpan.Controls.Add(pictureBox13);
            updtUsrpan.Controls.Add(label6);
            updtUsrpan.Controls.Add(textBox1);
            updtUsrpan.Controls.Add(pictureBox12);
            updtUsrpan.Controls.Add(checkBox2);
            updtUsrpan.Controls.Add(button1);
            updtUsrpan.Controls.Add(label13);
            updtUsrpan.Controls.Add(emtxtbx);
            updtUsrpan.Controls.Add(pictureBox8);
            updtUsrpan.Controls.Add(label8);
            updtUsrpan.Controls.Add(textBox4);
            updtUsrpan.Controls.Add(pictureBox5);
            updtUsrpan.Controls.Add(label14);
            updtUsrpan.Controls.Add(textBox6);
            updtUsrpan.Controls.Add(pictureBox9);
            updtUsrpan.Controls.Add(label12);
            updtUsrpan.Controls.Add(lntxtbx);
            updtUsrpan.Controls.Add(pictureBox7);
            updtUsrpan.Controls.Add(label11);
            updtUsrpan.Controls.Add(fntxtbx);
            updtUsrpan.Controls.Add(pictureBox6);
            updtUsrpan.Controls.Add(label3);
            updtUsrpan.Controls.Add(textBox3);
            updtUsrpan.Controls.Add(pictureBox4);
            updtUsrpan.Controls.Add(pictureBox3);
            updtUsrpan.Location = new Point(4, 77);
            updtUsrpan.Name = "updtUsrpan";
            updtUsrpan.Size = new Size(682, 456);
            updtUsrpan.TabIndex = 36;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.FromArgb(33, 46, 74);
            label7.FlatStyle = FlatStyle.Flat;
            label7.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.LightSteelBlue;
            label7.Location = new Point(359, 99);
            label7.Name = "label7";
            label7.Size = new Size(37, 13);
            label7.TabIndex = 82;
            label7.Text = "Credit";
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(33, 46, 74);
            textBox2.BorderStyle = BorderStyle.None;
            textBox2.Cursor = Cursors.Hand;
            textBox2.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.ForeColor = Color.White;
            textBox2.Location = new Point(361, 121);
            textBox2.Name = "textBox2";
            textBox2.RightToLeft = RightToLeft.No;
            textBox2.Size = new Size(296, 24);
            textBox2.TabIndex = 80;
            // 
            // pictureBox13
            // 
            pictureBox13.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox13.BackgroundImageLayout = ImageLayout.None;
            pictureBox13.Location = new Point(350, 96);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(307, 61);
            pictureBox13.TabIndex = 81;
            pictureBox13.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.FromArgb(33, 46, 74);
            label6.FlatStyle = FlatStyle.Flat;
            label6.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.LightSteelBlue;
            label6.Location = new Point(35, 33);
            label6.Name = "label6";
            label6.Size = new Size(92, 13);
            label6.TabIndex = 79;
            label6.Text = "Target Username";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(33, 46, 74);
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Cursor = Cursors.Hand;
            textBox1.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.ForeColor = Color.White;
            textBox1.Location = new Point(37, 54);
            textBox1.Name = "textBox1";
            textBox1.RightToLeft = RightToLeft.No;
            textBox1.Size = new Size(296, 24);
            textBox1.TabIndex = 77;
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox12.BackgroundImageLayout = ImageLayout.None;
            pictureBox12.Location = new Point(26, 29);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(307, 61);
            pictureBox12.TabIndex = 78;
            pictureBox12.TabStop = false;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.BackColor = Color.FromArgb(22, 30, 49);
            checkBox2.BackgroundImageLayout = ImageLayout.None;
            checkBox2.Cursor = Cursors.Hand;
            checkBox2.FlatStyle = FlatStyle.Flat;
            checkBox2.Font = new Font("Lato Semibold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox2.ForeColor = Color.LightSteelBlue;
            checkBox2.Location = new Point(26, 303);
            checkBox2.Name = "checkBox2";
            checkBox2.RightToLeft = RightToLeft.No;
            checkBox2.Size = new Size(113, 20);
            checkBox2.TabIndex = 76;
            checkBox2.Text = "Show Password";
            checkBox2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(248, 177, 121);
            button1.BackgroundImageLayout = ImageLayout.None;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.FromArgb(22, 30, 49);
            button1.Location = new Point(292, 328);
            button1.Name = "button1";
            button1.Size = new Size(97, 28);
            button1.TabIndex = 75;
            button1.Text = "Confirm";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.FromArgb(33, 46, 74);
            label13.FlatStyle = FlatStyle.Flat;
            label13.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = Color.LightSteelBlue;
            label13.Location = new Point(35, 99);
            label13.Name = "label13";
            label13.Size = new Size(34, 13);
            label13.TabIndex = 74;
            label13.Text = "Email";
            // 
            // emtxtbx
            // 
            emtxtbx.BackColor = Color.FromArgb(33, 46, 74);
            emtxtbx.BorderStyle = BorderStyle.None;
            emtxtbx.Cursor = Cursors.Hand;
            emtxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            emtxtbx.ForeColor = Color.White;
            emtxtbx.Location = new Point(37, 121);
            emtxtbx.Name = "emtxtbx";
            emtxtbx.RightToLeft = RightToLeft.No;
            emtxtbx.Size = new Size(296, 24);
            emtxtbx.TabIndex = 72;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox8.BackgroundImageLayout = ImageLayout.None;
            pictureBox8.Location = new Point(26, 96);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(307, 61);
            pictureBox8.TabIndex = 73;
            pictureBox8.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.FromArgb(33, 46, 74);
            label8.FlatStyle = FlatStyle.Flat;
            label8.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.LightSteelBlue;
            label8.Location = new Point(359, 32);
            label8.Name = "label8";
            label8.Size = new Size(83, 13);
            label8.TabIndex = 71;
            label8.Text = "New Username";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.FromArgb(33, 46, 74);
            textBox4.BorderStyle = BorderStyle.None;
            textBox4.Cursor = Cursors.Hand;
            textBox4.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox4.ForeColor = Color.White;
            textBox4.Location = new Point(361, 54);
            textBox4.Name = "textBox4";
            textBox4.RightToLeft = RightToLeft.No;
            textBox4.Size = new Size(296, 24);
            textBox4.TabIndex = 69;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox5.BackgroundImageLayout = ImageLayout.None;
            pictureBox5.Location = new Point(350, 29);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(307, 61);
            pictureBox5.TabIndex = 70;
            pictureBox5.TabStop = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.FromArgb(33, 46, 74);
            label14.FlatStyle = FlatStyle.Flat;
            label14.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label14.ForeColor = Color.LightSteelBlue;
            label14.Location = new Point(359, 233);
            label14.Name = "label14";
            label14.Size = new Size(96, 13);
            label14.TabIndex = 68;
            label14.Text = "Confirm Password";
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.FromArgb(33, 46, 74);
            textBox6.BorderStyle = BorderStyle.None;
            textBox6.Cursor = Cursors.Hand;
            textBox6.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.ForeColor = Color.White;
            textBox6.Location = new Point(361, 255);
            textBox6.Name = "textBox6";
            textBox6.PasswordChar = '•';
            textBox6.RightToLeft = RightToLeft.No;
            textBox6.Size = new Size(296, 24);
            textBox6.TabIndex = 66;
            // 
            // pictureBox9
            // 
            pictureBox9.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox9.BackgroundImageLayout = ImageLayout.None;
            pictureBox9.Location = new Point(350, 230);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(307, 61);
            pictureBox9.TabIndex = 67;
            pictureBox9.TabStop = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.FromArgb(33, 46, 74);
            label12.FlatStyle = FlatStyle.Flat;
            label12.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.LightSteelBlue;
            label12.Location = new Point(359, 166);
            label12.Name = "label12";
            label12.Size = new Size(60, 13);
            label12.TabIndex = 65;
            label12.Text = "Last Name";
            // 
            // lntxtbx
            // 
            lntxtbx.BackColor = Color.FromArgb(33, 46, 74);
            lntxtbx.BorderStyle = BorderStyle.None;
            lntxtbx.Cursor = Cursors.Hand;
            lntxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lntxtbx.ForeColor = Color.White;
            lntxtbx.Location = new Point(361, 188);
            lntxtbx.Name = "lntxtbx";
            lntxtbx.RightToLeft = RightToLeft.No;
            lntxtbx.Size = new Size(296, 24);
            lntxtbx.TabIndex = 63;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox7.BackgroundImageLayout = ImageLayout.None;
            pictureBox7.Location = new Point(350, 163);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(307, 61);
            pictureBox7.TabIndex = 64;
            pictureBox7.TabStop = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.FromArgb(33, 46, 74);
            label11.FlatStyle = FlatStyle.Flat;
            label11.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.LightSteelBlue;
            label11.Location = new Point(35, 166);
            label11.Name = "label11";
            label11.Size = new Size(61, 13);
            label11.TabIndex = 62;
            label11.Text = "First Name";
            // 
            // fntxtbx
            // 
            fntxtbx.BackColor = Color.FromArgb(33, 46, 74);
            fntxtbx.BorderStyle = BorderStyle.None;
            fntxtbx.Cursor = Cursors.Hand;
            fntxtbx.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            fntxtbx.ForeColor = Color.White;
            fntxtbx.Location = new Point(37, 188);
            fntxtbx.Name = "fntxtbx";
            fntxtbx.RightToLeft = RightToLeft.No;
            fntxtbx.Size = new Size(296, 24);
            fntxtbx.TabIndex = 60;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox6.BackgroundImageLayout = ImageLayout.None;
            pictureBox6.Location = new Point(26, 163);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(307, 61);
            pictureBox6.TabIndex = 61;
            pictureBox6.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(33, 46, 74);
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Lato Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.LightSteelBlue;
            label3.Location = new Point(35, 233);
            label3.Name = "label3";
            label3.Size = new Size(81, 13);
            label3.TabIndex = 59;
            label3.Text = "New Password";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(33, 46, 74);
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Cursor = Cursors.Hand;
            textBox3.Font = new Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.ForeColor = Color.White;
            textBox3.Location = new Point(37, 255);
            textBox3.Name = "textBox3";
            textBox3.PasswordChar = '•';
            textBox3.RightToLeft = RightToLeft.No;
            textBox3.Size = new Size(296, 24);
            textBox3.TabIndex = 57;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.FromArgb(33, 46, 74);
            pictureBox4.BackgroundImageLayout = ImageLayout.None;
            pictureBox4.Location = new Point(26, 230);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(307, 61);
            pictureBox4.TabIndex = 58;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.FromArgb(248, 177, 121);
            pictureBox3.Location = new Point(-1, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(160, 3);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 16;
            pictureBox3.TabStop = false;
            // 
            // update_sup_admin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(22, 30, 49);
            Controls.Add(updtUsrpan);
            Controls.Add(updtSrvcpan);
            Controls.Add(updtSrvcBtn);
            Controls.Add(updtUsrBtn);
            Controls.Add(label4);
            Controls.Add(pictureBox1);
            Name = "update_sup_admin";
            Size = new Size(691, 540);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            updtSrvcpan.ResumeLayout(false);
            updtSrvcpan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            updtUsrpan.ResumeLayout(false);
            updtUsrpan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label4;
        private PictureBox pictureBox1;
        private Button updtSrvcBtn;
        private Button updtUsrBtn;
        private Panel updtSrvcpan;
        private PictureBox pictureBox2;
        private Label label5;
        private Label label2;
        private Label label1;
        private Button button2;
        private TextBox price_bx;
        private PictureBox pictureBox10;
        private TextBox sn_box;
        private PictureBox pictureBox11;
        private ComboBox comboBox2;
        private Panel updtUsrpan;
        private PictureBox pictureBox3;
        private CheckBox checkBox2;
        private Button button1;
        private Label label13;
        private TextBox emtxtbx;
        private PictureBox pictureBox8;
        private Label label8;
        private TextBox textBox4;
        private PictureBox pictureBox5;
        private Label label14;
        private TextBox textBox6;
        private PictureBox pictureBox9;
        private Label label12;
        private TextBox lntxtbx;
        private PictureBox pictureBox7;
        private Label label11;
        private TextBox fntxtbx;
        private PictureBox pictureBox6;
        private Label label3;
        private TextBox textBox3;
        private PictureBox pictureBox4;
        private Label label7;
        private TextBox textBox2;
        private PictureBox pictureBox13;
        private Label label6;
        private TextBox textBox1;
        private PictureBox pictureBox12;
    }
}
